"""
Library for SX1276 chipset (Raspberry Pi Linux version)

Ported from MicroPython to Linux Python.
Uses spidev + RPi.GPIO.
"""

import time
import spidev
import RPi.GPIO as GPIO
GPIO.setwarnings(False)

# SX1276 registers
_REG_FIFO = 0x00
_REG_OP_MODE = 0x01
_REG_FR_MSB = 0x06
_REG_FR_MID = 0x07
_REG_FR_LSB = 0x08
_REG_PA_CONFIG = 0x09
_REG_FIFO_ADDR_PTR = 0x0D
_REG_FIFO_RX_CURRENT_ADDR = 0x10
_REG_IRQ_FLAGS = 0x12
_REG_RX_NB_BYTES = 0x13
_REG_PKT_SNR = 0x19
_REG_PKT_RSSI = 0x1A
_REG_MODEM_CONFIG1 = 0x1D
_REG_MODEM_CONFIG2 = 0x1E
_REG_PAYLOAD_LENGHT = 0x22
_REG_MODEM_CONFIG3 = 0x26
_REG_INVERT_IQ = 0x33
_REG_SYNC_WORD = 0x39
_REG_INVERT_IQ2 = 0x3B
_REG_DIO_MAPPING_1 = 0x40
_REG_VERSION = 0x42
_REG_PA_DAC = 0x4D

# modes
_MODE_SLEEP = 0x00
_MODE_STDBY = 0x01
_MODE_TX = 0x03
_MODE_RXCONT = 0x05
_MODE_LORA = 0x80


class Transceiver:
    """
    SX1276 Transceiver (Linux)
    """

    def __init__(self, spi_bus, spi_cs, cs_pin, rst_pin, dio0_pin):
        # SPI
        self.spi = spidev.SpiDev()
        self.spi.open(spi_bus, spi_cs)
        self.spi.max_speed_hz = 400_000
        self.spi.mode = 0

        # GPIO
        GPIO.setmode(GPIO.BCM)
        self.cs = cs_pin
        self.rst = rst_pin
        self.dio0 = dio0_pin

        GPIO.setup(self.cs, GPIO.OUT, initial=GPIO.HIGH)
        GPIO.setup(self.rst, GPIO.OUT, initial=GPIO.HIGH)
        GPIO.setup(self.dio0, GPIO.IN)

        # Reset SX1276
        GPIO.output(self.rst, 0)
        time.sleep(1)
        GPIO.output(self.rst, 1)
        time.sleep(0.1)

        # Check SPI
        version = self.read(_REG_VERSION, 2)[1]
        if version == 0x12:
            print("SPI working, version check passed")
        else:
            raise RuntimeError("SX1276 not detected (version=0x{:02X})".format(version))

        # Enter LoRa sleep
        self.write(_REG_OP_MODE, _MODE_LORA | _MODE_SLEEP)
        self.settings()

    # -------------------------------------------------------------

    def settings(
        self,
        power=17,
        sf=7,
        bw=125,
        cr=4 / 5,
        syn_word=0x12,
        inv_iq=False,
        crc=False,
        exp_header=True,
    ):
        # Power
        if power < 2:
            power = 2
        if power <= 17:
            self.write(_REG_PA_CONFIG, 0xF0 | (power - 2))
        elif power == 20:
            self.write(_REG_PA_CONFIG, 0xFF)
            self.write(_REG_PA_DAC, 0x87)

        # CRC + SF
        crc_flag = 0x04 if crc else 0x00
        self.write(_REG_MODEM_CONFIG2, (sf << 4) | crc_flag)

        # LDRO
        if (bw == 125 and sf >= 11) or (bw == 250 and sf == 12):
            self.write(_REG_MODEM_CONFIG3, 0x0C)

        # Bandwidth + coding rate
        bandwidths = {
            7.8: 0x00,
            10.4: 0x10,
            15.6: 0x20,
            20.8: 0x30,
            31.25: 0x40,
            41.7: 0x50,
            62.5: 0x60,
            125: 0x70,
            250: 0x80,
            500: 0x90,
        }

        code_rates = {
            4 / 5: 0x02,
            4 / 6: 0x04,
            4 / 7: 0x06,
            4 / 8: 0x08,
        }

        bw_reg = bandwidths.get(bw, 0x70)
        cr_reg = code_rates.get(cr, 0x02)
        header = 0x00 if exp_header else 0x01

        self.write(_REG_MODEM_CONFIG1, bw_reg | cr_reg | header)

        # Sync word
        self.write(_REG_SYNC_WORD, syn_word)

        # IQ inversion
        if inv_iq:
            self.write(_REG_INVERT_IQ, 0x66)
            self.write(_REG_INVERT_IQ2, 0x19)
        else:
            self.write(_REG_INVERT_IQ, 0x27)
            self.write(_REG_INVERT_IQ2, 0x1D)

    # -------------------------------------------------------------

    def set_freq(self, freq):
        if freq < 137:
            raise ValueError("Invalid frequency")
        frf = int(freq * (2**19) / 32)
        self.write(_REG_FR_MSB, (frf >> 16) & 0xFF)
        self.write(_REG_FR_MID, (frf >> 8) & 0xFF)
        self.write(_REG_FR_LSB, frf & 0xFF)

    # -------------------------------------------------------------

    def send(self, msg, freq=868.1):
        if isinstance(msg, str):
            msg = msg.encode()

        self.set_freq(freq)
        self.write(_REG_DIO_MAPPING_1, 0x40)

        self.write(_REG_OP_MODE, _MODE_LORA | _MODE_STDBY)
        self.write(_REG_PAYLOAD_LENGHT, len(msg))
        self.write(_REG_FIFO_ADDR_PTR, 0x80)
        self.write(_REG_FIFO, msg)

        self.write(_REG_OP_MODE, _MODE_LORA | _MODE_TX)

        while not GPIO.input(self.dio0):
            time.sleep(0.01)

        self.write(_REG_OP_MODE, _MODE_LORA | _MODE_SLEEP)
        print("Transmission successful")

    # -------------------------------------------------------------

    def receive(self, freq=868.1, timeout=0):
        self.set_freq(freq)
        self.write(_REG_DIO_MAPPING_1, 0x00)
        self.write(_REG_OP_MODE, _MODE_LORA | _MODE_STDBY)
        self.write(_REG_FIFO_ADDR_PTR, 0x00)
        self.write(_REG_OP_MODE, _MODE_LORA | _MODE_RXCONT)

        start = time.time()
        while not GPIO.input(self.dio0):
            if timeout and (time.time() - start) > timeout:
                return None, None, None
            time.sleep(0.01)

        irq = self.read(_REG_IRQ_FLAGS, 2)[1]
        if irq & 0x20:
            return None, None, None

        num_bytes = self.read(_REG_RX_NB_BYTES, 2)[1]
        snr, rssi = self.get_meta()

        addr = self.read(_REG_FIFO_RX_CURRENT_ADDR, 2)[1]
        self.write(_REG_FIFO_ADDR_PTR, addr)

        msg = self.read(_REG_FIFO, num_bytes + 1)[1:]
        self.write(_REG_OP_MODE, _MODE_LORA | _MODE_SLEEP)

        return msg, snr, rssi

    # -------------------------------------------------------------

    def get_meta(self):
        port_const = -157
        snr = self.read(_REG_PKT_SNR, 2)[1]
        if snr & 0x80:
            snr -= 256
        snr_db = snr / 4

        pkt_rssi = self.read(_REG_PKT_RSSI, 2)[1]
        rssi_db = port_const + pkt_rssi + (snr_db if snr_db < 0 else 0)

        return snr_db, rssi_db

    # -------------------------------------------------------------

    def write(self, address, data):
        GPIO.output(self.cs, 0)
        time.sleep(0.001)
        if isinstance(data, int):
            self.spi.xfer2([address | 0x80, data])
        else:
            self.spi.xfer2([address | 0x80] + list(data))
        GPIO.output(self.cs, 1)

    def read(self, address, length):
        GPIO.output(self.cs, 0)
        data = self.spi.xfer2([address & 0x7F] + [0x00] * (length - 1))
        GPIO.output(self.cs, 1)
        return data
