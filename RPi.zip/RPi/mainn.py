from sx127x import SX127xReceiver
import time
import signal
import sys

# Raspberry Pi pin mapping (BCM) - LoRa Hat v1.4
# ⚠️ CRITICAL: Verify these pins match YOUR specific HAT revision
# Check: GPIO readall | grep -E "RST|DIO0|CS"
SPI_BUS = 0
# NOTE: CS (GPIO 8) is handled automatically by spidev - do NOT set it up manually
SPI_SPEED = 100_000  # ✓ CHANGED: Reduced from 5MHz to 100kHz for stability
RESET_PIN = 25      # ✓ CHANGED: HAT RST typically on GPIO 25 (verify!)
DIO0_PIN = 24       # ✓ CHANGED: HAT DIO0 typically on GPIO 24 (verify!)

# Graceful shutdown handler
def cleanup(signum, frame):
    print("\n[INFO] Shutting down...")
    lora.cleanup()
    sys.exit(0)

signal.signal(signal.SIGINT, cleanup)

lora = SX127xReceiver(
    spi_bus=SPI_BUS,
    spi_speed=SPI_SPEED,
    reset_pin=RESET_PIN,
    dio0_pin=DIO0_PIN,
    freq=868.1
)

print("\n-- LoRa SX127x Receiver (Raspberry Pi) --")
print(f"[INFO] Listening on 868.1 MHz...")
print(f"[INFO] GPIO Config - RST:{RESET_PIN}, DIO0:{DIO0_PIN}, CS:{SPI_CS}")
print(f"[INFO] SPI Speed: {SPI_SPEED/1e6:.1f} MHz\n")

try:
    while True:
        packet = lora.receive_packet()
        if packet:
            try:
                msg = packet.decode()
            except UnicodeDecodeError:
                msg = packet

            print("[RX]", msg)
            print(
                "      RSSI = {:.2f} dBm | SNR = {:.2f} dB"
                .format(lora.packet_rssi(), lora.packet_snr())
            )
            print("-" * 40)
        else:
            # Uncomment for debugging (shows activity)
            # print(".", end="", flush=True)
            pass

        time.sleep(0.05)
except KeyboardInterrupt:
    pass
finally:
    cleanup(None, None)
